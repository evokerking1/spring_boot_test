package dev.evokerking.Evokerking_test_hello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvokerkingTestHelloApplication {

	public static void main(String[] args) {
		SpringApplication.run(EvokerkingTestHelloApplication.class, args);
	}

}
